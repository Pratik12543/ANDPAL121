import { useState } from 'react';

type PostOffice = {
  Name: string;
  Description?: string | null;
  BranchType?: string;
  DeliveryStatus?: string;
  Circle?: string;
  District?: string;
  Division?: string;
  Region?: string;
  Block?: string;
  State?: string;
  Country?: string;
  Pincode?: string;
};

type ApiResponse = {
  Message: string;
  Status: string;
  PostOffice: PostOffice[] | null;
};

const API_BASE = 'https://api.postalpincode.in';

export default function App() {
  const [activeTab, setActiveTab] = useState<'place' | 'pin'>('place');
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<PostOffice[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [copiedPin, setCopiedPin] = useState('');

  async function searchData() {
    const value = query.trim();
    setError('');
    setResults([]);
    setCopiedPin('');

    if (!value) {
      setError('Please enter a place name or PIN code.');
      return;
    }

    if (activeTab === 'pin' && !/^\d{6}$/.test(value)) {
      setError('Please enter a valid 6-digit PIN code.');
      return;
    }

    try {
      setLoading(true);
      const endpoint = activeTab === 'place' ? `/postoffice/${encodeURIComponent(value)}` : `/pincode/${value}`;
      const res = await fetch(`${API_BASE}${endpoint}`);
      const data: ApiResponse[] = await res.json();
      const postOffices = data?.[0]?.PostOffice || [];

      if (!postOffices.length) {
        setError('No results found. Try another place name or PIN code.');
        return;
      }

      setResults(postOffices);
    } catch {
      setError('Something went wrong. Please check your internet connection and try again.');
    } finally {
      setLoading(false);
    }
  }

  async function copyPin(pin?: string) {
    if (!pin) return;
    await navigator.clipboard.writeText(pin);
    setCopiedPin(pin);
    setTimeout(() => setCopiedPin(''), 1500);
  }

  function handleTabChange(tab: 'place' | 'pin') {
    setActiveTab(tab);
    setQuery('');
    setResults([]);
    setError('');
  }

  return (
    <main className="page">
      <section className="hero">
        <div className="badge">India PIN Code Finder</div>
        <h1>PIN Code Hub</h1>
        <p>Search any Indian place to find PIN codes, or enter a 6-digit PIN code to find full post office details.</p>
      </section>

      <section className="searchBox">
        <div className="tabs">
          <button className={activeTab === 'place' ? 'active' : ''} onClick={() => handleTabChange('place')}>Place → PIN</button>
          <button className={activeTab === 'pin' ? 'active' : ''} onClick={() => handleTabChange('pin')}>PIN → Place</button>
        </div>

        <div className="inputRow">
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && searchData()}
            placeholder={activeTab === 'place' ? 'Enter city, village, town or locality' : 'Enter 6-digit PIN code'}
            inputMode={activeTab === 'pin' ? 'numeric' : 'text'}
          />
          <button className="searchBtn" onClick={searchData} disabled={loading}>{loading ? 'Searching...' : 'Search'}</button>
        </div>

        {loading && <div className="spinner" />}
        {error && <p className="error">{error}</p>}
      </section>

      <section className="results">
        {results.map((item, index) => (
          <article className="card" key={`${item.Name}-${item.Pincode}-${index}`}>
            <div className="cardTop">
              <div>
                <h2>{item.Name}</h2>
                <p className="pin">PIN Code: <strong>{item.Pincode || 'N/A'}</strong></p>
              </div>
              <button className="copyBtn" onClick={() => copyPin(item.Pincode)}>{copiedPin === item.Pincode ? 'Copied' : 'Copy PIN'}</button>
            </div>

            <div className="grid">
              <Info label="District" value={item.District} />
              <Info label="State" value={item.State} />
              <Info label="Circle" value={item.Circle} />
              <Info label="Region" value={item.Region} />
              <Info label="Division" value={item.Division} />
              <Info label="Taluka / Block" value={item.Block} />
              <Info label="Branch Type" value={item.BranchType} />
              <Info label="Delivery Status" value={item.DeliveryStatus} />
            </div>
          </article>
        ))}
      </section>
    </main>
  );
}

function Info({ label, value }: { label: string; value?: string }) {
  return (
    <div className="info">
      <span>{label}</span>
      <strong>{value || 'N/A'}</strong>
    </div>
  );
}
